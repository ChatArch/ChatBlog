# Volcengine Plan AK/SK 工具包

这是独立、可导入的脚本工具包，不是新 PyPI 包。用火山 AK/SK 调控制面，再把**已有** Plan API Key 保存到具名 ChatEnv OpenAI profile。AK/SK 与模型 API Key 是不同凭据，不能混用。

## 安全边界

- 默认只读云 API；`ensure-existing` 只可能新建本地具名 profile，不创建云 Key。
- `create-agent --create-missing-agent-key` 是唯一云写入入口，供以后明确授权时使用。本轮整理没有执行它。没有创建 Coding Key 的接口，不猜 Coding Scene。
- Agent Scene 固定 `RealAgentPlanPersonal`；Coding 来自普通 Ark `ListApiKeys` 库存，**普通库存不等于全部是 Coding Key**。必须由用户确认并显式给 `--key-id`，绝不自动挑第一把。
- 多把 Agent Key 也必须明确 ID；库存 `TotalCount` 不等于实际条目数就拒绝继续，不猜分页参数、不把前 100 条当完整列表。
- 不创建 IAM 用户/登录密码，不购买、续费、轮换、删除 Key，不开启后付费。不全局 activate，不切换默认配置。
- API host、region、action/version 固定，禁用跳转和重试，不支持任意 URL/Action/Body CLI。
- AK/SK 只从 owner-only JSON 文件或 stdin 读取；命令行参数和环境变量不接受原始密钥。不要使用 shell `set -x`、HTTP 调试日志、抓包或记录原始 API 返回。
- CLI 默认只打印安全摘要。`list-keys --show-ids` 会显示用于选择的**私有资源 ID**，不是密钥；不要把它的输出公开。原始 API Key 从不打印，异常响应正文也不打印。
- `call()`、`list_keys()`、`raw_key()` 的 Python 返回值可能含私有元数据/密钥，供内存处理，**不要 print、记录、序列化到项目或日志**。
- 相同 key/base/model 的现有 profile 返回 `unchanged`，不写盘。任何不同内容都会拒绝覆盖，请另选 profile；锁保护本工具包并发保存，不能防止其他编辑器同时改文件。
- state 位于 `get_paths().home_dir / "volcengine"`，ChatEnv profiles 位于 `get_paths().envs_dir`。默认使用 ChatEnv 的 home，支持其 `CHATARCH_HOME` 解析，不把 state/secrets 写到工具包。

## 文件与安装

```text
README.md
requirements.txt
scripts/plan_toolkit.py       # 导入式 API + CLI
 tests/test_plan_toolkit.py   # 无网络 unittest
```

需要 Python 3.10+，当前实测环境是 macOS；profile 写锁用 `fcntl`，也适用于 Linux，未做跨平台验收。不支持 Windows 原生写锁。

进入解压后的工具包目录：

```sh
VENV="$HOME/.chatarch/volcengine/.venv"
uv venv --python 3.12 "$VENV"
uv pip install --python "$VENV/bin/python" -r requirements.txt
export PY="$VENV/bin/python"
export PYTHONDONTWRITEBYTECODE=1
"$PY" scripts/plan_toolkit.py --tree
"$PY" scripts/plan_toolkit.py --help
```

如已有安装好三个依赖的 ChatArch venv，可用该 venv 的 Python 替代 `"$PY"`，无需再次安装。

## 1. 准备 AK/SK（只使用自己授权的凭据）

默认读取 ChatEnv home 下 `volcengine/credentials/user-authorized-ak.json`，字段恰为 `access_key_id`、`secret_access_key`。文件需 0600、当前用户所有、不能是符号链接。已有安全文件无需复制。

也可显式指定文件路径（只把路径写入 shell，不写 secret）：

```sh
"$PY" scripts/plan_toolkit.py --credentials-file "$AK_FILE" identity
```

未保存安全文件时，可用下列无回显交互把 JSON 直接送入 stdin，既不落盘，也不在 shell history 放入 AK/SK。请在有 TTY 的终端执行：

```sh
"$PY" -c 'import getpass,json; print(json.dumps({"access_key_id":getpass.getpass("AK: "),"secret_access_key":getpass.getpass("SK: ")}))' | "$PY" scripts/plan_toolkit.py --credentials-stdin identity
```

不要用带明文 secret 的 `echo` 命令。stdin 只对当前一次调用有效；后续命令需要同样提供输入或使用安全文件。

## 2. 身份、套餐和库存（云端只读）

以下命令默认使用安全文件；自定义文件时将 `--credentials-file "$AK_FILE"` 放在子命令前。

```sh
"$PY" scripts/plan_toolkit.py identity
"$PY" scripts/plan_toolkit.py plan --kind coding
"$PY" scripts/plan_toolkit.py plan --kind agent
"$PY" scripts/plan_toolkit.py list-keys --kind coding
"$PY" scripts/plan_toolkit.py list-keys --kind agent
# 仅在自己的终端显示私有 ID，确认用途后选取；请勿发布输出。
"$PY" scripts/plan_toolkit.py list-keys --kind coding --show-ids
"$PY" scripts/plan_toolkit.py list-keys --kind agent --show-ids
```

身份摘要只包含验证成功及账户/身份字段是否存在的布尔值，不打印账户号。套餐读取不修改自动续费。

## 3. 获取已有 Key → 保存具名 ChatEnv profile

先将自己已确认的**资源 ID（不是 API Key）**赋给 `CODING_KEY_ID`/`AGENT_KEY_ID`，然后：

```sh
"$PY" scripts/plan_toolkit.py ensure-existing --kind coding --key-id "$CODING_KEY_ID" --profile volcengine-coding-plan
"$PY" scripts/plan_toolkit.py ensure-existing --kind agent --key-id "$AGENT_KEY_ID" --profile volcengine-agent-plan
```

Agent 库存只有一把且 Active 时可省略 `--key-id`；Coding 无论库存几把都不可省略。找不到、非 Active、选择不唯一均停止。保存后通过 ChatEnv 原 API 再读取并逐值验证。不会调用 activate。默认 model 为 `doubao-seed-2.0-code`；如需其他已确认 model 可显式加 `--model`，但不要把未经模型请求验证的 model 声称为可用。

固定模型服务地址：

| 类型 | 精确 base URL |
|---|---|
| Coding | https://ark.cn-beijing.volces.com/api/coding/v3 |
| Agent | https://ark.cn-beijing.volces.com/api/plan/v3 |

## 4. 将来创建缺失 Agent Key（显式写入，当前不要重跑）

**只有确认账号内没有 Agent Key、获得新授权且确有需要时才执行：**

```sh
"$PY" scripts/plan_toolkit.py create-agent --profile volcengine-agent-plan --create-missing-agent-key
```

先列完整 Agent 库存：已有 Key 就走 existing 流程，不再创建。目标 profile 已存在但库存为空也拒绝创建。创建固定名称 `chatenv-agent-plan`、项目 `default`、Scene `RealAgentPlanPersonal`、资源范围 `[{"ResourceId":"*","ResourceType":"all"}]`，这沿用此前已成功请求，不增加 IAM 权限。

创建前用排他方式写入 `volcengine/agent-key-create-intent.json`（0600，fsync）。单次请求结束后只读列表回读，即使请求抛异常也**不重试创建**。仅确认唯一 Active 且名称相符才继续保存 profile。若结果未知，marker 保留，之后再运行也不能发送第二次创建：

```sh
"$PY" scripts/plan_toolkit.py list-keys --kind agent --show-ids
"$PY" scripts/plan_toolkit.py ensure-existing --kind agent --key-id "$AGENT_KEY_ID" --profile volcengine-agent-plan
```

列表暂时为空：停止并人工核对控制台/服务端结果，**不要自动删除 marker、循环 create 或猜另一个 Scene**。单一全局 intent 是刻意保守的限制；新账号/下一次创建需要另行人工审核，不提供 reset 开关。

## 5. 可选模型 smoke（会消耗请求，不属于只读控制面验收）

只有明确允许消耗一次模型请求才运行。每条命令各一次，`max_retries=0`，最大输出 32 tokens，`thinking.type=disabled`，失败无备用 endpoint。

```sh
"$PY" scripts/plan_toolkit.py smoke --kind coding --profile volcengine-coding-plan --protocol responses --allow-model-request
"$PY" scripts/plan_toolkit.py smoke --kind coding --profile volcengine-coding-plan --protocol chat --allow-model-request
"$PY" scripts/plan_toolkit.py smoke --kind agent --profile volcengine-agent-plan --protocol responses --allow-model-request
"$PY" scripts/plan_toolkit.py smoke --kind agent --profile volcengine-agent-plan --protocol chat --allow-model-request
```

读取的是传入的**具名 profile**，校验对应精确 base，不读取 global active。只返回 `request_succeeded` / `marker_present` 等安全摘要，不输出模型原文。marker 必须精确为 PLAN_OK，缺失时 CLI 返回非零；验收仍检查两个字段均为 true。

**不要用当前 `chatenv test -t oai -I` 验收具名 Plan：**主流程发现仅传 OpenAI 环境变量仍可能读取另一个全局 active profile，且输出 Failed 时退出码仍可为 0。本工具包没有调用该命令，不会为了测试去 activate。检查真实输出成功状态，而非只检查退出码。

## Python API

```python
import sys
sys.path.insert(0, "scripts")
from plan_toolkit import PlanClient

client = PlanClient()  # 默认安全文件；或 PlanClient(credentials_file)
identity = client.caller()  # 安全摘要
subscription = client.plan("agent")
# 不 print 库存/原始返回值；读取 ID 后让调用方明确确认。
items = client.list_keys("agent")
# profile_result = client.ensure_existing("agent", "my-agent-profile", key_id=confirmed_id)
```

导出方法：`PlanClient(...) / from_stdin() / caller() / plan(kind) / list_keys(kind) / raw_key(id) / ensure_existing(...) / create_agent(...)`；函数 `save_profile(...) / smoke(...) / main(argv)`。底层 `call(action, body)` 仅允许验证过的只读形状，不能直接调用 Create；下划线方法属于内部实现，不供调用方绕过防护。

签名保留原脚本的 Volcengine HMAC-SHA256 canonical request、`cn-beijing` scope、Action/Version 和 `ArkListApiKeys → ListApiKeys` wire alias。未支持的白名单操作参数拒绝发送；不按名字猜 API。

## 测试、证据与边界

```sh
"$PY" -m unittest discover -s tests -v
```

测试使用合成 fixture 和 Mock，临时文件默认在当前目录的 `playground/toolkit-tests/`；也可设置 `TOOLKIT_TEST_ROOT`。不会读取真实 AK、不联网、不生成真实 Key。

- 原始脚本历史真实成功：AK caller、两套餐、普通/Agent 库存、GetRawApiKey、创建一把缺失 Agent Key、具名 ChatEnv 保存；其创建结果已在服务端，不应再次创建。
- 本工具包本轮：无网络 unittest + 真实只读 identity、两套餐、两库存、获取已有 Key 并核对原具名 profile；具体结果见最终验收记录。
- 本轮没有真实执行新创建分支、模型 smoke、付费动作或多账号场景；创建未知结果恢复和模型请求上限仅做无网络测试，不把模拟结果当线上成功。
- 凭据权限/IAM 限制、库存超过 100、API 契约演变、外部同时编辑 profile 会失败并停止；不会自动升级权限或回退付费路径。
