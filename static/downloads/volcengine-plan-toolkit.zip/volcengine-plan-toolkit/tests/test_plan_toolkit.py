import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch, MagicMock

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
AVAILABLE = importlib.util.find_spec("plan_toolkit") is not None
if AVAILABLE:
    import plan_toolkit as m


class SurfaceTests(unittest.TestCase):
    def test_importable_toolkit_exists(self):
        self.assertTrue(AVAILABLE, "Missing importable plan_toolkit implementation")


@unittest.skipUnless(AVAILABLE, "Implementation not present yet")
class SafetyTests(unittest.TestCase):
    def setUp(self):
        test_root = Path(os.environ.get("TOOLKIT_TEST_ROOT", str(Path.cwd() / "playground/toolkit-tests")))
        test_root.mkdir(parents=True, exist_ok=True)
        self.tmp = tempfile.TemporaryDirectory(dir=test_root)
        self.addCleanup(self.tmp.cleanup)
        self.home = Path(self.tmp.name)
        self.paths = patch("plan_toolkit.get_paths", return_value=type("Paths", (), {"home_dir": self.home, "envs_dir": self.home / "envs"})())
        self.paths.start()
        self.addCleanup(self.paths.stop)
        self.file = self.home / "credentials.json"
        self.file.write_text(json.dumps({"access_key_id": "fixture-ak", "secret_access_key": "fixture-sk"}))
        self.file.chmod(0o600)
        self.client = m.PlanClient(self.file)
        self.key = "fixture-only-not-a-real-key-000000000000"
        self.item = {"Id": "fixture-id", "Status": "Active", "Name": m.AGENT_NAME}

    def test_reject_arbitrary_action_and_parameter_injection(self):
        with patch("plan_toolkit.requests.Session") as session:
            for action, body in [("DeleteApiKey", {}), ("GetPersonalPlanAPIKey", {}), ("GetCallerIdentity", {"Action": "CreateApiKey"}), ("CreateApiKey", {})]:
                with self.assertRaises(m.PlanError): self.client.call(action, body)
            session.assert_not_called()

    def test_fixed_scene_and_incomplete_inventory(self):
        with patch.object(self.client, "call", return_value={"TotalCount": 2, "Items": [self.item]}) as call:
            with self.assertRaises(m.PlanError): self.client.list_keys("agent")
            self.assertEqual(call.call_args.args[1]["Filter"]["Scene"], "RealAgentPlanPersonal")

    def test_numeric_wire_id_is_preserved(self):
        with patch.object(self.client, "_request", return_value={"ApiKey": self.key}) as request:
            self.assertEqual(self.client.raw_key(123, kind="coding"), self.key)
            self.assertEqual(request.call_args.args[1], {"Id": 123, "ProjectName": "default"})

    def test_cli_string_selects_numeric_inventory_id(self):
        item = {**self.item, "Id": 123}
        with patch.object(self.client, "list_keys", return_value=[item]), patch.object(self.client, "raw_key", return_value=self.key):
            result = self.client.ensure_existing("coding", "fixture-profile", "123")
            self.assertTrue(result["key_present"])

    def test_coding_requires_explicit_id_even_single(self):
        with patch.object(self.client, "list_keys", return_value=[self.item]):
            with self.assertRaises(m.PlanError): self.client.ensure_existing("coding", "test-profile")

    def test_multiple_agent_keys_require_id(self):
        with patch.object(self.client, "list_keys", return_value=[self.item, {**self.item, "Id": "fixture-other"}]):
            with self.assertRaises(m.PlanError): self.client.ensure_existing("agent", "test-profile")

    def test_save_profile_readback_no_activate_no_overwrite(self):
        r = m.save_profile("fixture-profile", "agent", self.key)
        self.assertTrue(r["key_present"])
        self.assertEqual(r["status"], "saved")
        store = m.EnvStore(m.get_paths().envs_dir)
        path = store.profile_path(m.OpenAIConfig, "fixture-profile")
        before = path.read_bytes()
        stat = path.stat().st_mtime_ns
        self.assertEqual(m.save_profile("fixture-profile", "agent", self.key)["status"], "unchanged")
        self.assertEqual(path.stat().st_mtime_ns, stat)
        with self.assertRaises(m.PlanError): m.save_profile("fixture-profile", "agent", "different-fixture-secret-000000000000")
        self.assertEqual(path.read_bytes(), before)
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)
        self.assertFalse((m.get_paths().envs_dir / "OpenAI" / "default.env").exists())

    def test_existing_different_base_is_not_rewritten(self):
        store = m.EnvStore(m.get_paths().envs_dir)
        store.save_profile(m.OpenAIConfig, "fixture-profile", {"OPENAI_API_KEY": self.key, "OPENAI_API_BASE": m.BASES["coding"], "OPENAI_API_MODEL": m.MODEL})
        with self.assertRaises(m.PlanError): m.save_profile("fixture-profile", "agent", self.key)

    def test_existing_recovery_ignores_marker_and_never_creates(self):
        state = self.home / "volcengine"
        state.mkdir(mode=0o700)
        (state / "agent-key-create-intent.json").write_text("{}")
        with patch.object(self.client, "list_keys", return_value=[self.item]), patch.object(self.client, "raw_key", return_value=self.key), patch.object(self.client, "_request") as request:
            result = self.client.create_agent("fixture-profile", create_missing_agent_key=True)
            self.assertTrue(result["key_present"])
            request.assert_not_called()

    def test_create_without_flag_never_requests(self):
        with patch.object(self.client, "list_keys") as keys:
            with self.assertRaises(m.PlanError): self.client.create_agent("fixture-profile")
            keys.assert_not_called()

    def test_unknown_create_result_recovers_via_list_without_retry(self):
        with patch.object(self.client, "list_keys", side_effect=[[], [self.item]]), patch.object(self.client, "raw_key", return_value=self.key), patch.object(self.client, "_request", side_effect=m.PlanError("request failed")) as request:
            r = self.client.create_agent("fixture-profile", create_missing_agent_key=True)
            self.assertTrue(r["key_present"])
            self.assertEqual(request.call_count, 1)
        with patch.object(self.client, "list_keys", return_value=[]), patch.object(self.client, "_request") as request:
            with self.assertRaises(m.PlanError): self.client.create_agent("fixture-profile", create_missing_agent_key=True)
            request.assert_not_called()

    def test_refuse_creation_if_profile_already_populated(self):
        m.save_profile("fixture-profile", "agent", self.key)
        with patch.object(self.client, "list_keys", return_value=[]), patch.object(self.client, "_request") as request:
            with self.assertRaises(m.PlanError): self.client.create_agent("fixture-profile", create_missing_agent_key=True)
            request.assert_not_called()

    def test_safe_http_errors_and_no_redirects_or_retries(self):
        session = MagicMock()
        session.request.side_effect = RuntimeError("fixture-ak fixture-sk " + self.key)
        with patch("plan_toolkit.requests.Session", return_value=session):
            with self.assertRaises(m.PlanError) as error: self.client.caller()
        self.assertNotIn("fixture", str(error.exception))
        self.assertEqual(session.request.call_count, 1)
        self.assertFalse(session.request.call_args.kwargs["allow_redirects"])

    def test_safe_cli_exception_and_identity(self):
        output, error = io.StringIO(), io.StringIO()
        with patch.object(m.PlanClient, "caller", side_effect=RuntimeError(self.key)), contextlib.redirect_stdout(output), contextlib.redirect_stderr(error):
            self.assertEqual(m.main(["--credentials-file", str(self.file), "identity"]), 1)
        self.assertNotIn(self.key, output.getvalue() + error.getvalue())
        with patch.object(self.client, "call", return_value={"AccountId": 123, "IdentityId": "private-fixture", "Trn": "private-fixture", "IdentityType": "User"}):
            summary = self.client.caller()
        self.assertNotIn("private-fixture", json.dumps(summary))
        self.assertNotIn("123", json.dumps(summary))

    def test_unsafe_credential_file_permissions(self):
        self.file.chmod(0o644)
        with self.assertRaises(m.PlanError): m.PlanClient(self.file)

    def test_stdin_credentials_and_repr_do_not_leak(self):
        c = m.PlanClient.from_stdin(io.StringIO(self.file.read_text()))
        self.assertNotIn("fixture", repr(c))

    def test_smoke_explicit_and_bounded(self):
        m.save_profile("fixture-profile", "agent", self.key)
        with self.assertRaises(m.PlanError): m.smoke("agent", "fixture-profile", "responses")
        fake = MagicMock()
        fake.__enter__.return_value = fake
        for protocol in ("responses", "chat"):
            with patch("openai.OpenAI", return_value=fake) as constructor:
                m.smoke("agent", "fixture-profile", protocol, allow_model_request=True)
            self.assertEqual(constructor.call_args.kwargs["max_retries"], 0)
            call = fake.responses.create if protocol == "responses" else fake.chat.completions.create
            args = call.call_args.kwargs
            self.assertEqual(args.get("max_output_tokens", args.get("max_tokens")), 32)
            self.assertEqual(args["extra_body"], {"thinking": {"type": "disabled"}})


if __name__ == "__main__":
    unittest.main()
