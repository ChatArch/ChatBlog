#!/usr/bin/env python3
"""Narrow, default-read-only Volcengine Plan control API and CLI.

call()/raw_key() return sensitive data in memory: never print their result.
Only CLI-safe summaries are printed. No raw HTTP body or exception logging.
"""
import argparse
import datetime
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import stat
import sys
from types import MappingProxyType
from urllib.parse import urlencode

import requests
from chatenv import EnvStore, OpenAIConfig, get_paths

ALLOW = MappingProxyType({
    'GetCallerIdentity': ('sts', 'sts.volcengineapi.com', '2018-01-01', 'GET'),
    'GetPersonalPlan': ('ark', 'ark.cn-beijing.volcengineapi.com', '2024-01-01', 'POST'),
    'GetAFPUsage': ('ark', 'ark.cn-beijing.volcengineapi.com', '2024-01-01', 'POST'),
    'ListApiKeys': ('iam', 'iam.volcengineapi.com', '2018-01-01', 'GET'),
    'ArkListApiKeys': ('ark', 'ark.cn-beijing.volcengineapi.com', '2024-01-01', 'POST'),
    'GetRawApiKey': ('ark', 'ark.cn-beijing.volcengineapi.com', '2024-01-01', 'POST'),
    'ListAgentPlanHarnessOverdraftStatus': ('ark', 'ark.cn-beijing.volcengineapi.com', '2024-01-01', 'POST'),
    'CreateApiKey': ('ark', 'ark.cn-beijing.volcengineapi.com', '2024-01-01', 'POST'),
})
BASES = MappingProxyType({
    'coding': 'https://ark.cn-beijing.volces.com/api/coding/v3',
    'agent': 'https://ark.cn-beijing.volces.com/api/plan/v3',
})
PLANS = {'coding': 'CodingPlan', 'agent': 'AgentPlan'}
MODEL = 'doubao-seed-2.0-code'
AGENT_NAME = 'chatenv-agent-plan'
SCENE = 'RealAgentPlanPersonal'


class PlanError(RuntimeError):
    """A fixed safe diagnostic, never a raw provider response."""


def _kind(kind):
    if kind not in BASES:
        raise PlanError('Choose coding or agent.')
    return kind


def _profile(name):
    if not isinstance(name, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,79}', name) or name == 'default':
        raise PlanError('A non-default named profile is required.')
    return name


def _valid_key(key):
    if not isinstance(key, str) or len(key) <= 20 or any(c.isspace() for c in key) or '*' in key or '[' in key:
        raise PlanError('Missing, malformed or masked API key.')
    return key


def _store():
    return EnvStore(get_paths().envs_dir)


def _private_dir():
    path = get_paths().home_dir / 'volcengine'
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    if path.is_symlink() or (os.name == 'posix' and path.stat().st_mode & 0o077):
        raise PlanError('State directory must be private (0700), not a symlink.')
    return path


def save_profile(profile, kind, key, model=MODEL):
    """Save/read back a named ChatEnv profile; never activate or overwrite one."""
    _profile(profile)
    _kind(kind)
    _valid_key(key)
    values = {'OPENAI_API_KEY': key, 'OPENAI_API_BASE': BASES[kind], 'OPENAI_API_MODEL': model}
    store = _store()

    def inspect():
        current = store.load_profile(OpenAIConfig, profile)
        if current:
            if any(current.get(k) != v for k, v in values.items()):
                raise PlanError('Existing profile differs; choose a new profile. Nothing overwritten.')
            return True
        return False

    if inspect():
        return {'profile': profile, 'kind': kind, 'status': 'unchanged', 'key_present': True}
    # Cooperative cross-process lock; ChatEnv remains the profile writer.
    lock = _private_dir() / ('profile-' + hashlib.sha256(profile.encode()).hexdigest() + '.lock')
    import fcntl
    with lock.open('a') as handle:
        os.chmod(lock, 0o600)
        fcntl.flock(handle, fcntl.LOCK_EX)
        unchanged = inspect()
        if not unchanged:
            store.save_profile(OpenAIConfig, profile, values)
        if not inspect():
            raise PlanError('Profile readback failed.')
    return {'profile': profile, 'kind': kind, 'status': 'unchanged' if unchanged else 'saved', 'key_present': True}


class PlanClient:
    def __init__(self, credentials_file=None):
        path = Path(credentials_file).expanduser() if credentials_file else get_paths().home_dir / 'volcengine' / 'credentials' / 'user-authorized-ak.json'
        try:
            flags = os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0)
            fd = os.open(path, flags)
            with os.fdopen(fd) as handle:
                mode = os.fstat(handle.fileno())
                if not stat.S_ISREG(mode.st_mode) or (os.name == 'posix' and (mode.st_mode & 0o077 or mode.st_uid != os.getuid())):
                    raise PlanError('Credentials must be an owner-only regular file (0600).')
                self._load(json.load(handle))
        except PlanError:
            raise
        except Exception:
            raise PlanError('Cannot read valid credentials from the secure file.') from None

    @classmethod
    def from_stdin(cls, stream=None):
        """Consume a credentials JSON object; no argv/env secret values."""
        obj = cls.__new__(cls)
        try:
            obj._load(json.load(stream or sys.stdin))
        except Exception:
            raise PlanError('Invalid credentials JSON on stdin.') from None
        return obj

    def _load(self, data):
        ak, sk = data['access_key_id'], data['secret_access_key']
        if not all(isinstance(v, str) and v and not any(c.isspace() for c in v) for v in (ak, sk)):
            raise PlanError('Invalid credential values.')
        self._ak, self._sk = ak, sk

    def call(self, action, body=None):
        """Read-only allowlisted dispatch. Raw results can be sensitive."""
        body = body or {}
        if action not in ALLOW or action == 'CreateApiKey' or not isinstance(body, dict):
            raise PlanError('Action is outside the read-only allowlist.')
        valid = False
        if action in ('GetCallerIdentity', 'GetAFPUsage'):
            valid = not body
        elif action == 'GetPersonalPlan':
            valid = set(body) == {'Plan'} and body['Plan'] in PLANS.values()
        elif action == 'ListApiKeys':
            valid = body == {'Limit': 100, 'Offset': 0}
        elif action == 'ArkListApiKeys':
            valid = body in ({'PageSize': 100, 'ProjectName': 'default'}, {'PageSize': 100, 'ProjectName': 'default', 'Filter': {'Scene': SCENE}})
        elif action == 'GetRawApiKey':
            valid = set(body) in ({'Id'}, {'Id', 'ProjectName'}) and type(body.get('Id')) in (str, int) and bool(body['Id']) and body.get('ProjectName', 'default') == 'default'
        elif action == 'ListAgentPlanHarnessOverdraftStatus':
            valid = body == {'Edition': 'agent_plan_personal'}
        if not valid:
            raise PlanError('Request parameters are outside the verified contract.')
        return self._request(action, body)

    def _request(self, action, body):
        service, host, version, method = ALLOW[action]
        stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        wire_action = 'ListApiKeys' if action == 'ArkListApiKeys' else action
        query_values = {'Action': wire_action, 'Version': version}
        if method == 'GET' and body:
            query_values.update(body)
        query = urlencode(sorted(query_values.items()))
        payload = b'' if method == 'GET' else json.dumps(body or {}, separators=(',', ':')).encode()
        digest = hashlib.sha256(payload).hexdigest()
        headers = {'Host': host, 'X-Date': stamp, 'X-Content-Sha256': digest}
        if method != 'GET':
            headers['Content-Type'] = 'application/json'
        normalized = {k.lower(): v for k, v in headers.items()}
        names = ';'.join(sorted(normalized))
        canonical_headers = ''.join(k + ':' + normalized[k] + '\n' for k in sorted(normalized))
        canonical = '\n'.join([method, '/', query, canonical_headers, names, digest])
        scope = '/'.join([stamp[:8], 'cn-beijing', service, 'request'])
        string = '\n'.join(['HMAC-SHA256', stamp, scope, hashlib.sha256(canonical.encode()).hexdigest()])
        key = self._sk.encode()
        for part in [stamp[:8], 'cn-beijing', service, 'request']:
            key = hmac.new(key, part.encode(), hashlib.sha256).digest()
        signature = hmac.new(key, string.encode(), hashlib.sha256).hexdigest()
        headers['Authorization'] = f'HMAC-SHA256 Credential={self._ak}/{scope}, SignedHeaders={names}, Signature={signature}'
        try:
            session = requests.Session()
            try:
                # Requests defaults to zero retries; make it explicit as a safety contract.
                session.mount('https://', requests.adapters.HTTPAdapter(max_retries=0))
                response = session.request(method, f'https://{host}/?{query}', headers=headers, data=payload, timeout=(10, 30), allow_redirects=False)
                data = response.json()
            finally:
                session.close()
            if response.status_code != 200 or data.get('ResponseMetadata', {}).get('Error') or not isinstance(data.get('Result'), dict):
                raise PlanError('Control API rejected the request; response body suppressed.')
            return data['Result']
        except PlanError:
            raise
        except Exception:
            raise PlanError('Control API request failed; result may be unknown. Do not retry creation.') from None

    def caller(self):
        data = self.call('GetCallerIdentity')
        return {'authenticated': True, 'account_present': bool(data.get('AccountId')), 'identity_present': bool(data.get('IdentityId'))}

    def plan(self, kind):
        data = self.call('GetPersonalPlan', {'Plan': PLANS[_kind(kind)]})
        return {k: v for k, v in data.items() if k in ('PlanType', 'Status', 'StartTime', 'EndTime', 'AutoRenew')}

    def list_keys(self, kind):
        """Return private key metadata in memory. Refuse incomplete inventories."""
        query = {'PageSize': 100, 'ProjectName': 'default'}
        if _kind(kind) == 'agent':
            query['Filter'] = {'Scene': SCENE}
        result = self.call('ArkListApiKeys', query)
        items = result.get('Items')
        if not isinstance(items, list) or result.get('TotalCount') != len(items):
            raise PlanError('Incomplete key inventory; no selection or creation allowed.')
        if any(not isinstance(i, dict) or not i.get('Id') for i in items):
            raise PlanError('Malformed key inventory.')
        return items

    def raw_key(self, key_id, kind='agent'):
        """Sensitive in-memory key; prefer ensure_existing() to avoid printing it."""
        _kind(kind)
        body = {'Id': key_id}
        if kind == 'coding':
            body['ProjectName'] = 'default'
        return _valid_key(self.call('GetRawApiKey', body)['ApiKey'])

    def ensure_existing(self, kind, profile, key_id=None, model=MODEL):
        _kind(kind)
        _profile(profile)
        if kind == 'coding' and not key_id:
            raise PlanError('Coding key must be selected with an explicit key ID from the ordinary inventory.')
        items = self.list_keys(kind)
        if key_id:
            selected = [i for i in items if str(i['Id']) == str(key_id)]
        else:
            selected = items if len(items) == 1 else []
        if len(selected) != 1 or selected[0].get('Status') != 'Active':
            raise PlanError('No unique active key selected; use an explicit ID. No key was created.')
        return save_profile(profile, kind, self.raw_key(selected[0]['Id'], kind=kind), model)

    def create_agent(self, profile, *, create_missing_agent_key=False, key_id=None, model=MODEL):
        """Explicit future-only creation; persistent intent + read-after-unknown recovery."""
        if not create_missing_agent_key:
            raise PlanError('Creation requires --create-missing-agent-key.')
        _profile(profile)
        items = self.list_keys('agent')
        if items:
            return self.ensure_existing('agent', profile, key_id, model)
        if key_id:
            raise PlanError('Requested key ID does not exist; refusing to create a replacement.')
        if _store().load_profile(OpenAIConfig, profile):
            raise PlanError('Target profile already exists; no new cloud key created.')
        marker = _private_dir() / 'agent-key-create-intent.json'
        try:
            fd = os.open(marker, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            raise PlanError('Prior creation intent exists. Reconcile via list; never automatically retry or remove the marker.') from None
        with os.fdopen(fd, 'w') as handle:
            json.dump({'action': 'CreateApiKey', 'scene': SCENE, 'state': 'attempted-do-not-retry'}, handle)
            handle.flush()
            os.fsync(handle.fileno())
        body = {'Name': AGENT_NAME, 'ProjectName': 'default', 'ResourceInstances': [{'ResourceId': '*', 'ResourceType': 'all'}], 'Scene': SCENE}
        try:
            self._request('CreateApiKey', body)
        except PlanError:
            pass  # Only read reconciliation below; never issue a second CreateApiKey.
        items = self.list_keys('agent')
        if len(items) != 1 or items[0].get('Name') != AGENT_NAME or items[0].get('Status') != 'Active':
            raise PlanError('Creation unresolved. Inspect list and select a key explicitly; marker retained.')
        return save_profile(profile, 'agent', self.raw_key(items[0]['Id']), model)


def smoke(kind, profile, protocol, *, allow_model_request=False):
    """Exactly one explicit model request; no model text or response bodies returned."""
    if not allow_model_request or protocol not in ('responses', 'chat'):
        raise PlanError('Model smoke requires explicit --allow-model-request and a known protocol.')
    _kind(kind)
    _profile(profile)
    values = _store().load_profile(OpenAIConfig, profile)
    if values.get('OPENAI_API_BASE', '').rstrip('/') != BASES[kind]:
        raise PlanError('Profile endpoint differs from the exact Plan endpoint; no fallback.')
    key = _valid_key(values.get('OPENAI_API_KEY'))
    if not values.get('OPENAI_API_MODEL'):
        raise PlanError('Profile has no model.')
    from openai import OpenAI
    try:
        with OpenAI(api_key=key, base_url=BASES[kind], timeout=30, max_retries=0) as client:
            common = {'model': values['OPENAI_API_MODEL'], 'extra_body': {'thinking': {'type': 'disabled'}}}
            if protocol == 'responses':
                result = client.responses.create(input='只回复 PLAN_OK，不要解释。', max_output_tokens=32, **common)
                text = result.output_text
            else:
                result = client.chat.completions.create(messages=[{'role': 'user', 'content': '只回复 PLAN_OK，不要解释。'}], max_tokens=32, **common)
                text = result.choices[0].message.content
        return {'profile': profile, 'kind': kind, 'protocol': protocol, 'request_succeeded': True, 'marker_present': isinstance(text, str) and text.strip() == 'PLAN_OK'}
    except Exception:
        raise PlanError('Model request failed; no retry and no raw error output.') from None


class SafeParser(argparse.ArgumentParser):
    def error(self, message):
        # argparse normally echoes arbitrary argv tokens, which can contain secrets.
        raise PlanError('Invalid arguments. Use --help; never pass credentials as argument values.')


def parser():
    p = SafeParser(description=__doc__)
    source = p.add_mutually_exclusive_group()
    source.add_argument('--credentials-file', help='Owner-only AK/SK JSON file; default is under ChatEnv home.')
    source.add_argument('--credentials-stdin', action='store_true', help='Read AK/SK JSON from stdin.')
    p.add_argument('--tree', action='store_true', help='Show command tree without credentials or network.')
    subs = p.add_subparsers(dest='command')
    subs.add_parser('identity', help='Read identity, print only presence booleans.')
    plan = subs.add_parser('plan', help='Read subscription; does not buy or renew.')
    plan.add_argument('--kind', choices=BASES, required=True)
    keys = subs.add_parser('list-keys', help='Agent scene or ordinary inventory; coding classification is manual.')
    keys.add_argument('--kind', choices=BASES, required=True)
    keys.add_argument('--show-ids', action='store_true', help='Print private IDs for explicit selection; do not publish output.')
    for cmd in ('ensure-existing', 'create-agent', 'smoke'):
        sub = subs.add_parser(cmd)
        if cmd != 'create-agent':
            sub.add_argument('--kind', choices=BASES, required=True)
        sub.add_argument('--profile', required=True, help='Named ChatEnv OpenAI profile; default is forbidden.')
        if cmd == 'smoke':
            sub.add_argument('--protocol', choices=('responses', 'chat'), required=True)
            sub.add_argument('--allow-model-request', action='store_true')
        else:
            sub.add_argument('--key-id', help='Existing private key ID, never the raw key.')
            sub.add_argument('--model', default=MODEL)
        if cmd == 'create-agent':
            sub.add_argument('--create-missing-agent-key', action='store_true')
    return p


def main(argv=None):
    try:
        args = parser().parse_args(argv)
        if args.tree:
            commands = next(a for a in parser()._actions if isinstance(a, argparse._SubParsersAction)).choices
            print('plan_toolkit\n' + '\n'.join('  ' + name for name in commands))
            return 0
        if not args.command:
            parser().print_help()
            return 0
        client = None
        if args.command == 'smoke':
            result = smoke(args.kind, args.profile, args.protocol, allow_model_request=args.allow_model_request)
        else:
            client = PlanClient.from_stdin() if args.credentials_stdin else PlanClient(args.credentials_file)
            if args.command == 'identity':
                result = client.caller()
            elif args.command == 'plan':
                result = client.plan(args.kind)
            elif args.command == 'list-keys':
                items = client.list_keys(args.kind)
                result = {'kind': args.kind, 'count': len(items), 'active_count': sum(i.get('Status') == 'Active' for i in items)}
                if args.show_ids:
                    result['items'] = [{'id': i['Id'], 'active': i.get('Status') == 'Active'} for i in items]
            elif args.command == 'ensure-existing':
                result = client.ensure_existing(args.kind, args.profile, args.key_id, args.model)
            else:
                result = client.create_agent(args.profile, create_missing_agent_key=args.create_missing_agent_key, key_id=args.key_id, model=args.model)
        output = json.dumps(result, ensure_ascii=False, sort_keys=True)
        if client:
            output = output.replace(client._ak, '[REDACTED]').replace(client._sk, '[REDACTED]')
        print(output)
        return 1 if args.command == "smoke" and not result["marker_present"] else 0
    except PlanError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    except Exception:
        print('Operation failed; details suppressed to protect credentials.', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
