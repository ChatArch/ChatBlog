#!/usr/bin/env python3
"""Run one bounded request through a named ChatEnv Plan profile."""
import argparse
import json
from urllib.parse import urlsplit

from chatenv import EnvStore, OpenAIConfig, get_paths
from openai import OpenAI

BASES = {
    "volcengine-coding-plan":
        "https://ark.cn-beijing.volces.com/api/coding/v3",
    "volcengine-agent-plan":
        "https://ark.cn-beijing.volces.com/api/plan/v3",
}


def run(profile: str, protocol: str) -> dict:
    values = EnvStore(get_paths().envs_dir).load_profile(
        OpenAIConfig, profile
    )
    base = values.get("OPENAI_API_BASE", "").rstrip("/")
    if base != BASES[profile]:
        raise ValueError("Profile must use its exact Plan endpoint; no fallback.")
    key = values.get("OPENAI_API_KEY", "")
    if not key or "*" in key:
        raise ValueError("Missing real API key; masked values are not credentials.")
    model = values["OPENAI_API_MODEL"]
    with OpenAI(api_key=key, base_url=base, timeout=30, max_retries=0) as client:
        if protocol == "responses":
            result = client.responses.create(
                model=model,
                input="只回复 PLAN_OK，不要解释。",
                max_output_tokens=32,
                extra_body={"thinking": {"type": "disabled"}},
            )
            text = result.output_text
        else:
            result = client.chat.completions.create(
                model=model,
                messages=[{
                    "role": "user",
                    "content": "只回复 PLAN_OK，不要解释。",
                }],
                max_tokens=32,
                extra_body={"thinking": {"type": "disabled"}},
            )
            text = result.choices[0].message.content
        return {
            "profile": profile,
            "protocol": protocol,
            "path": urlsplit(base).path + (
                "/responses" if protocol == "responses"
                else "/chat/completions"
            ),
            "model": model,
            "text": text,
            "usage": result.usage.model_dump() if result.usage else None,
        }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=BASES, required=True)
    parser.add_argument(
        "--protocol", choices=["responses", "chat"], default="responses"
    )
    args = parser.parse_args()
    print(json.dumps(
        run(args.profile, args.protocol), ensure_ascii=False, indent=2
    ))
