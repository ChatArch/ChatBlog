import argparse
from getpass import getpass

from chatenv import EnvStore, OpenAIConfig, get_paths

BASES = {
    "volcengine-coding-plan":
        "https://ark.cn-beijing.volces.com/api/coding/v3",
    "volcengine-agent-plan":
        "https://ark.cn-beijing.volces.com/api/plan/v3",
}

parser = argparse.ArgumentParser()
parser.add_argument("profile", choices=BASES)
args = parser.parse_args()

key = getpass("粘贴完整 API Key（输入不回显）: ").strip()
if not key or "*" in key:
    raise SystemExit("需要完整密钥，不能使用掩码。")

store = EnvStore(get_paths().envs_dir)
old = store.load_profile(OpenAIConfig, args.profile)
if old.get("OPENAI_API_KEY") not in (None, "", key):
    raise SystemExit("该 profile 已有不同密钥；停止，未覆盖。")

values = {
    "OPENAI_API_KEY": key,
    "OPENAI_API_BASE": BASES[args.profile],
    "OPENAI_API_MODEL": "doubao-seed-2.0-code",
}
path = store.save_profile(OpenAIConfig, args.profile, values)
assert store.load_profile(OpenAIConfig, args.profile) == values
print(f"已保存 {args.profile}，未切换默认配置。")
print(f"文件：{path}")
