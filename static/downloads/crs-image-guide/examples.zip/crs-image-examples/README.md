# 用 CRS 生成一张中文教学图

Python 路径只依赖 ChatEnv 和系统 curl，不需要安装 ChatImg。示例脚本不是 ChatImg 内置命令。

## Python + ChatEnv（主路径）

需要 Python 3.10+。在已准备的虚拟环境内：

```bash
python -m pip install "chatenv==0.2.11"
curl --version
chatenv new -t oai crs
```

已有 crs profile 时跳过 new；命令不会切换默认配置。在 `~/.chatarch/envs/OpenAI/crs.env` 填写：

```dotenv
OPENAI_API_BASE=https://crs.example.com/openai/v1
OPENAI_API_KEY=<YOUR_CRS_API_KEY>
OPENAI_API_MODEL=gpt-5.5
```

替换自己的 HTTPS 服务地址和完整 CRS Key。若设置 CHATARCH_HOME，配置位于该目录下的 envs/OpenAI/crs.env。模型名称需由服务向该 Key 开放。

```bash
python generate_image.py --profile crs --image-model gpt-image-2 --size 1536x1024 --quality medium --prompt-file prompt.txt --output quicksort.png
```

脚本读取地址、Key 和承载模型；图片模型由 `--image-model` 指定，不读取 OPENAI_IMAGE_MODEL。

生成成功留下 quicksort.png、quicksort.request.json 和 quicksort.sse。输出名已存在时会停止；每次生成请使用新名字。

仅从已有成功响应重新提取，不调用模型：

```bash
python generate_image.py --decode quicksort.sse --output quicksort-copy.png
```

## 纯 curl（替代路径，不是下一步）

需要 Bash、curl、jq 和 base64。运行它会另发一次生成请求，两条路径选一条即可。

```bash
export CRS_API_BASE='https://crs.example.com/openai/v1'
read -r -s -p 'CRS API Key: ' CRS_API_KEY
printf '\n'
export CRS_API_KEY
bash curl_image_tool.sh request.json quicksort-curl.png
```

Key 不写入请求 JSON 或 curl 参数。Python 路径修改 prompt.txt；纯 curl 路径修改 request.json 中的 input_text。
