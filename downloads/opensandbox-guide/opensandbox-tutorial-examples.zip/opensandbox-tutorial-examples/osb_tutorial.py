from datetime import timedelta
from pathlib import Path
import os

from opensandbox import SandboxSync
from opensandbox.config import ConnectionConfigSync
from opensandbox.models import WriteEntry
from opensandbox.models.execd import RunCommandOpts


def connection():
    return ConnectionConfigSync(
        domain='127.0.0.1:8080',
        protocol='http',
        api_key=os.environ['OPEN_SANDBOX_API_KEY'],
    )


def new_sandbox(image='python:3.12-slim', memory='512Mi'):
    return SandboxSync.create(
        image,
        entrypoint=['tail', '-f', '/dev/null'],
        timeout=timedelta(minutes=10),
        ready_timeout=timedelta(seconds=60),
        resource={'cpu': '1', 'memory': memory},
        connection_config=connection(),
    )


def run_ok(sb, command, cwd='/workspace', seconds=60):
    result = sb.commands.run(
        command,
        opts=RunCommandOpts(
            working_directory=cwd,
            timeout=timedelta(seconds=seconds),
        ),
    )
    if result.text:
        print(result.text)
    stderr = '\n'.join(x.text for x in result.logs.stderr)
    if stderr:
        print(stderr)
    if result.error is not None or result.exit_code != 0:
        raise RuntimeError(
            f'命令未成功：exit={result.exit_code}, '
            f'error={result.error}, stderr={stderr}'
        )
    return result


def main():
    sb = new_sandbox()
    print('Sandbox ID:', sb.id)
    try:
        run_ok(sb, 'mkdir -p /workspace', cwd='/')
        sb.files.write_files([
            WriteEntry(
                path='/workspace/hello.py',
                data="print('hello from sandbox')\n",
                mode=644,
            )
        ])
        run_ok(sb, 'python hello.py')
        source = sb.files.read_file('/workspace/hello.py')
        Path('hello.exported.py').write_text(source, encoding='utf-8')
        print('脚本已导出到本机 hello.exported.py')
    finally:
        sb.destroy()


if __name__ == '__main__':
    main()
