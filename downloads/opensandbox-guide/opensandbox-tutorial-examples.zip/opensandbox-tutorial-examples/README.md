# OpenSandbox 教程示例

主文包含完整的 Server/Docker 准备过程；本包仅包含调用侧示例，没有服务凭据或数据。

## 前置条件
- Python 3.10+；已按文章启动有鉴权的 OpenSandbox Server。
- SDK侧环境变量 OPEN_SANDBOX_API_KEY 已安全加载。
- 默认管理地址 127.0.0.1:8080；修改时编辑 osb_tutorial.py 的 connection()。
- 先在 Server/SDK/Docker 同机的可信学习环境使用，不将本文配置直接当公开多租户平台。

## 安装与执行
在解压目录创建并激活 venv，然后执行：

```bash
python -m pip install -r requirements.txt
python osb_tutorial.py
python case_csv.py
python case_tests.py
python case_web.py
```

case_web.py等待回车，回车后销毁环境。案例的环境和命令均有独立时限；不按回车不意味着网页永久托管。

解释器案例另需 Docker 执行节点上的官方专用镜像：

```bash
docker pull opensandbox/code-interpreter:v1.1.0
python case_interpreter.py
```

## 文件
- osb_tutorial.py：连接、创建、受控执行、基础文件导出及清理。
- case_csv.py / orders.csv：CSV输入与summary.json导出。
- case_tests.py：Python代码与unittest。
- case_web.py：后台HTTP服务、端点解析和就绪读取。
- case_interpreter.py：语言context内的变量保留。

## 范围
接口按1.2.1发布包静态核对，程序与嵌入脚本做过语法检查；不将此描述为Docker运行通过。不要加入真实Key后分享此目录，也不要向不可信程序传入高权限凭据或宿主机敏感挂载。
