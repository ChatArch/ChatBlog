from datetime import timedelta
import time
import httpx
from opensandbox.models.execd import RunCommandOpts
from osb_tutorial import new_sandbox, run_ok

sb = new_sandbox()
try:
    run_ok(sb, 'mkdir -p /workspace/site', cwd='/')
    sb.files.write_file('/workspace/site/index.html', '<h1>Hello OpenSandbox</h1>', mode=644)
    job = sb.commands.run(
        'python -m http.server 8000 --bind 0.0.0.0',
        opts=RunCommandOpts(
            background=True,
            working_directory='/workspace/site',
            timeout=timedelta(minutes=5),
        ),
    )
    if job.error:
        raise RuntimeError(str(job.error))

    ep = sb.get_endpoint(8000)
    url = ep.endpoint if '://' in ep.endpoint else 'http://' + ep.endpoint
    with httpx.Client(trust_env=False, follow_redirects=False, timeout=2) as client:
        for _ in range(30):
            try:
                response = client.get(url, headers=ep.headers)
                response.raise_for_status()
                break
            except (httpx.ConnectError, httpx.ConnectTimeout):
                time.sleep(0.2)
        else:
            raise RuntimeError('HTTP服务没有就绪')

    print('Sandbox内端口8000对应的访问地址：', url)
    print('后台命令ID：', job.id)
    print('本例只在Docker/Server所在机器上提供本地访问。')
    input('浏览完成后按回车，销毁这个临时环境：')
finally:
    sb.destroy()
