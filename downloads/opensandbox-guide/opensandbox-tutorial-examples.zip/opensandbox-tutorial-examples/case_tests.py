from osb_tutorial import new_sandbox, run_ok
from opensandbox.models import WriteEntry

NORMALIZER = '''def normalize(text):
    return text.strip().lower()
'''
TESTS = '''import unittest
from normalize import normalize

class Tests(unittest.TestCase):
    def test_trim_and_case(self):
        self.assertEqual(normalize('  Hello  '), 'hello')

    def test_empty(self):
        self.assertEqual(normalize(''), '')
'''

sb = new_sandbox()
try:
    run_ok(sb, 'mkdir -p /workspace', cwd='/')
    sb.files.write_files([
        WriteEntry(path='/workspace/normalize.py', data=NORMALIZER, mode=644),
        WriteEntry(path='/workspace/test_normalize.py', data=TESTS, mode=644),
    ])
    run_ok(sb, 'python -m unittest -v')
finally:
    sb.destroy()
