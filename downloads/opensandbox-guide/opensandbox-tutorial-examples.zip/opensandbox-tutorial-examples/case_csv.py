from pathlib import Path
from osb_tutorial import new_sandbox, run_ok
from opensandbox.models import WriteEntry

CSV_WORKER = '''import csv, json
from decimal import Decimal
from pathlib import Path
rows = list(csv.DictReader(Path('input.csv').open(encoding='utf-8')))
totals = {}
for row in rows:
    category = row['category']
    totals[category] = totals.get(category, Decimal('0')) + Decimal(row['amount'])
result = {'rows': len(rows), 'totals': {k: str(v) for k, v in totals.items()}}
Path('summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
'''

sb = new_sandbox()
try:
    run_ok(sb, 'mkdir -p /workspace', cwd='/')
    sb.files.write_files([
        WriteEntry(path='/workspace/input.csv', data=Path('orders.csv').read_text(encoding='utf-8'), mode=644),
        WriteEntry(path='/workspace/summarize.py', data=CSV_WORKER, mode=644),
    ])
    run_ok(sb, 'python summarize.py')
    result = sb.files.read_file('/workspace/summary.json')
    Path('summary.json').write_text(result, encoding='utf-8')
    print('统计结果已取回本机 summary.json')
finally:
    sb.destroy()
