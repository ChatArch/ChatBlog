from datetime import timedelta
from opensandbox import SandboxSync
from code_interpreter import CodeInterpreterSync
from osb_tutorial import connection

# 专用镜像按它的启动约定使用，不把通用例子的tail入口硬套上来
sb = SandboxSync.create(
    'opensandbox/code-interpreter:v1.1.0',
    timeout=timedelta(minutes=10),
    resource={'cpu': '1', 'memory': '2Gi'},
    connection_config=connection(),
)
interpreter = None
try:
    interpreter = CodeInterpreterSync.create(sb)
    context = interpreter.codes.create_context(language='python')
    first = interpreter.codes.run("message = 'hello from a kernel'", context=context)
    if first.error:
        raise RuntimeError(str(first.error))
    second = interpreter.codes.run('print(message)', context=context)
    if second.error:
        raise RuntimeError(str(second.error))
    print(second.text)
    interpreter.codes.delete_context(context.id)
finally:
    try:
        if interpreter is not None:
            interpreter.close()
    finally:
        sb.destroy()
